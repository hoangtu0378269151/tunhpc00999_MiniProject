package Tunhpc00999_MiniProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tunhpc00999MiniProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
