package Tunhpc00999_MiniProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tunhpc00999MiniProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tunhpc00999MiniProjectApplication.class, args);
	}

}
