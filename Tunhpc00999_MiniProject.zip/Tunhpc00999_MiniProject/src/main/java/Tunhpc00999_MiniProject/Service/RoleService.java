package Tunhpc00999_MiniProject.Service;



import java.util.List;

import Tunhpc00999_MiniProject.entity.Role;



public interface RoleService {
   public List<Role> findAll();
}
