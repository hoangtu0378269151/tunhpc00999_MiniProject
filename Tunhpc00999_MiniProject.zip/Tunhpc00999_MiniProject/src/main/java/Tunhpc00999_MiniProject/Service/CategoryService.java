package Tunhpc00999_MiniProject.Service;


import java.util.List;

import Tunhpc00999_MiniProject.entity.Category;


public interface CategoryService {

	List<Category> findAll();

}
