package Tunhpc00999_MiniProject.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import Tunhpc00999_MiniProject.entity.OrderDetail;


public interface OrderDetailDAO extends JpaRepository<OrderDetail, Long> {

}
